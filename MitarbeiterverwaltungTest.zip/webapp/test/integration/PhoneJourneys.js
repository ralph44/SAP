/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/pages/App",
	"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/pages/Browser",
	"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/pages/Master",
	"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/pages/Detail",
	"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "mitarbeiterverwaltung.MitarbeiterverwaltungTest.view."
	});

	sap.ui.require([
		"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/NavigationJourneyPhone",
		"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/NotFoundJourneyPhone",
		"mitarbeiterverwaltung/MitarbeiterverwaltungTest/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});